import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class SilkRoadTest.
 *
 * @author  Paula Días
 * @author Juan Pablo Vélez
 * @version 3
 */
public class SilkRoadCC2Test{
    /**
     * Default constructor for test class SilkRoadCC2Test
     */
    public SilkRoadCC2Test(){
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp(){
    }
    
    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @AfterEach
    public void tearDown(){
    }
}
