import java.util.ArrayList;
import java.util.Collections;
import java.util.Arrays;

/**
 * DOPO versión of the silk road problem with a graphical representation.
 * 
 * @author Paula Alejandra Díaz
 * @author Juan Pablo Vélez
 * @version 1
 */
public class SilkRoad{
    // Attributes
    private final int length;
    private int totalProfit;
    private final int days;
    private int actualDay;
    private boolean isVisible;
    private boolean lastDone;
    private ArrayList<Store> stores;
    private ArrayList<Robot> robots;
    private Road road;
    
    // Methods
    //Ciclo1
    //MiniCiclo1
    /**
     * Creates the silk road problem simulator
     * @param int length
     * @return SilkRoad
     */
    public SilkRoad(int length){
        //days y actual days los dejaremos para después.
        days = 0;
        actualDay = 0;
        //para después.
        
        this.length = length;
        totalProfit = 0;
        isVisible = false;
        lastDone = true;
        stores = new ArrayList(Collections.nCopies(length, null));
        robots = new ArrayList();
        //ajustar constructor
        road = new Road(length);
    }
    
    // Miniciclo2
    /**
     * adds a new store to the game if its posible
     * @param int location
     * @param int tenges
     */
    public void placeStore(int location, int tenges){
        if(road.in(location) && stores.get(location-1) == null){
            Store store = road.placeStore(location, tenges);
            stores.set(location-1, store);
            if(isVisible) store.makeVisible();
            lastDone = true;
        }else if(!road.in(location) || stores.get(location-1) != null){
            lastDone = false;
        }
    }
    
    /**
     * deletes a store from the game if its posible
     * @param int location
     * @return void
     */
    public void removeStore(int location){
        if(road.in(location) && stores.get(location-1) != null){
            road.removeStore(location);
            if(isVisible) stores.get(location-1).makeInvisible();
            stores.set(location-1, null);
            lastDone = true;
        }else if(!road.in(location) || stores.get(location-1) == null){
            lastDone = false;
        }
    }
    
    // Miniciclo2
    /**
     * adds a new robot to the game if its posible
     * @param int location
     * @return void
     */
    public void placeRobot(int location){
        if(road.in(location)){
            Robot robot = road.placeRobot(location);
            robots.add(robot);
            if(isVisible) robot.makeVisible();
            lastDone = true;
        }else if(!road.in(location)){
            lastDone = false;
        }
    }
    
    /**
     * deletes a robot from the game if its posible
     * @param int location
     * @return void
     */
    public void removeRobot(int location){
        if(road.in(location)){
            Robot robot = road.removeRobot(location);
            if(robot != null){
                robots.remove(robot);
                lastDone = true;
            }
        }else if(!road.in(location)){
            lastDone = false;
        }
    }
    
    // Miniciclo3
    /**
     * moves a robot from a given location a certain amount of meters
     * @param int location
     * @param int meters
     * @return void
     */
    public void moveRobot(int location, int meters) throws InterruptedException{
        if(road.in(location)){
            lastDone = road.moveRobot(location, meters);
        }
        lastDone = false;
    }
    
    /**
     * resupply all stores stashes
     * @return void
     */
    public void resupplyStores(){
        if(!stores.isEmpty()){
            for(Store s : stores){
                if(s != null) s.setFull(true);
            }
            lastDone = true;
        }else if(stores.isEmpty()){
            lastDone = false;
        }
    }
    
    /**
     * returns all robots to their initial location
     * @return void
     */
    public void returnRobots(){
        if(!robots.isEmpty()){
            
            for(Robot r : robots){
                if(isVisible) r.makeInvisible();
                r.moveInitial();
                if(isVisible) r.makeVisible();
            }
            lastDone = true;
        }else{
            lastDone = false;
        }
    }
    
    /**
     * set all stores to full and the robots to their initial location
     * @return void
     */
    public void reboot(){
        resupplyStores();
        returnRobots();
    }
    
    // Miniciclo4
    /**
     * Answers the total profit
     * @return int
     */
    public int profit(){
        int count = 0;
        for(Robot r : robots){
            count += r.getProfit();
        }
        totalProfit = count;
        return totalProfit;
    }
    
    /**
     * gives a list of stores by their location and stashes
     * @return int[][]
     */
    public int[][] stores(){
        int numberStores = countStores();
        int[][] answer = new int[numberStores][2];
        int i = 0;
        for(Store s : stores){
            answer[i][0] = s.getLocation();
            answer[i][1] = s.getStash();
            i++;
        }
        orderArray(answer);
        return answer;
    }
    
    /**
     * Counts the number of stores in the road
     */
    private int countStores(){
        int count = 0;
        for(Store s  : stores){
            if(s != null) count++;
        }
        return count;
    }
    
    /**
     * gives a list of robots ordered by their location and profit
     * @return in[][]
     */
    public int[][] robots(){
        int[][] answer = new int[robots.size()][2];
        int i = 0;
        for(Robot r : robots){
            answer[i][0] = r.getActualLocation();
            answer[i][1] = r.getProfit();
            i++;
        }
        orderArray(answer);
        return answer;
    }
    
    /**
     * Orders the given array by column, from smallest to biggest
     * @param int[][] array
     * @return int[][]
     */
    private int[][] orderArray(int[][] array){
        Arrays.sort(array, (a, b) ->{
            if (a[0] != b[0]) {
                return Integer.compare(a[0], b[0]); // columna 0
            } else {
                return Integer.compare(a[1], b[1]); // columna 1
            }
        });
        return array;
    }
    
    // Miniciclo5
    /**
     * makes the game visible in the canvas
     * @return void
     */
    public void makeVisible(){
        road.makeVisible();
        for(Store s : stores){
            if(s != null) s.makeVisible();
        }
        
        for(Robot r : robots){
            r.makeVisible();
        }
        isVisible = true;
    }
    
    /**
     * makes the game invisible in the canvas
     * @return void
     */
    public void makeInvisible(){
        road.makeInvisible();
        for(Store s : stores){
            if(s != null) s.makeInvisible();
        }
        
        for(Robot r : robots){
            r.makeInvisible();
        }
        isVisible = false;
    }
    
    // Miniciclo6
    /**
     * ends the game
     * @return void
     */
    public void finish(){
        System.exit(0);
    }
    
    /**
     * answers if the last operation was made
     * @return boolean
     */
    public boolean ok(){
        return lastDone;
    }
}
