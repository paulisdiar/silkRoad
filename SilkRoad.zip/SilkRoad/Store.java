/**
 * Is the class in charge of the graphical representation and behaviour of the stores in the silk road problem.
 * 
 * @author Paula Alejandra Díaz
 * @author Juan Pablo Vélez
 * @version 1
 */
public class Store{
    // Attributes
    private final int location;
    private Block block;
    private final int stash;
    private boolean full;
    private boolean isVisible;
    private Rectangle facade;
    private Triangle roof;
    
    // Methods
    /**
     * Constructor for objects of class Store
     * @param int location
     * @param int tenges
     * @param Block block
     * @return Store
     */
    public Store(int location, int tenges, Block block){
        this.location = location-1;
        this.block = block;
        stash = tenges;
        full = true;
        isVisible = false;
        int[] coordinates = this.block.getCoordinates();
        if(block.isHorizontal()){
            facade = new Rectangle(10, 10, coordinates[0]+20, (coordinates[1]-10)+5);
            roof = new Triangle(10, 10, (coordinates[0]+5)+20, (coordinates[1]-20)+5);
        }else if(!block.isHorizontal()){
            facade = new Rectangle(10, 10, coordinates[0]+27, (coordinates[1]-10)+35);
            roof = new Triangle(10, 10, (coordinates[0]+5)+27, (coordinates[1]-20)+35);
        }
    }
    
    /**
     * makes the store visible
     * @return void
     */
    public void makeVisible(){
        isVisible = true;
        facade.makeVisible();
        roof.makeVisible();
    }
    
    /**
     * makes the store invisible
     * @return void
     */
    public void makeInvisible(){
        isVisible = false;
        facade.makeInvisible();
        roof.makeInvisible();
    }
    
    /**
     * gives the stash amount
     * @return int
     */
    public int getStash(){
        return stash;
    }
    
    /**
     * Sets the block where the store is
     * @param Block block
     */
    public void setBlock(Block block){
        this.block = block;
    }
    
    /**
     * Answers if the store is full of tenges
     * @return boolean
     */
    public boolean isFull(){
        return full;
    }
    
    /**
     * Sets if the store is full or not
     * @param boolean is
     */
    public void setFull(boolean is){
        full = is;
    }
    
    /**
     * Gives the location of the store
     * @retun int
     */
    public int getLocation(){
        return location+1;
    }
}